.class public Lcom/validator/cheto/PuckTapListener;
.super Ljava/lang/Object;
.source "PuckTapListener.java"

.implements Landroid/view/View$OnTouchListener;

# ShootIt one-shot puck lock touch handler. Native attaches an instance of this to the PredictionOverlay
# via setOnTouchListener. It deliberately lives in a SECONDARY dex (classes8) instead of on
# PredictionOverlay, because the primary classes.dex is already at the 65536 method-reference limit and
# any ref added there overflows apktool's build. onTouch consumes a touch ONLY when ACTION_DOWN lands on
# one of OUR pucks (nativeHitTestPuck != 0, itself gated on Show-Pucks + Auto Play); everything else
# returns false so normal board play is untouched. On release it arms the one-shot lock for that puck.

# puck id pressed on ACTION_DOWN (0 = none), consumed on ACTION_UP
.field private pendingPuckId:I


.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public native nativeHitTestPuck(FF)I
.end method

.method public native nativeOnPuckTapLock(I)V
.end method

.method public native nativeDrawTouch(IFF)Z
.end method

.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 5

    # Draw paint mode: give native first refusal. While painting it captures the stroke (screen-px, clamped to
    # the arena) and returns true to CONSUME the gesture; otherwise it returns false and normal puck-tap runs.
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lcom/validator/cheto/PuckTapListener;->nativeDrawTouch(IFF)Z

    move-result v3

    if-eqz v3, :not_draw

    const/4 v4, 0x1

    return v4

    :not_draw
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    if-nez v0, :not_down

    # ACTION_DOWN -> which of our pucks (if any) is under the finger
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    invoke-virtual {p0, v1, v2}, Lcom/validator/cheto/PuckTapListener;->nativeHitTestPuck(FF)I

    move-result v3

    iput v3, p0, Lcom/validator/cheto/PuckTapListener;->pendingPuckId:I

    if-eqz v3, :pass

    const/4 v4, 0x1

    return v4

    :not_down
    const/4 v1, 0x1

    if-ne v0, v1, :not_up

    # ACTION_UP -> if a puck was pressed on DOWN, arm the one-shot lock
    iget v2, p0, Lcom/validator/cheto/PuckTapListener;->pendingPuckId:I

    if-eqz v2, :pass

    invoke-virtual {p0, v2}, Lcom/validator/cheto/PuckTapListener;->nativeOnPuckTapLock(I)V

    const/4 v3, 0x0

    iput v3, p0, Lcom/validator/cheto/PuckTapListener;->pendingPuckId:I

    const/4 v4, 0x1

    return v4

    :not_up
    # MOVE / CANCEL / others: keep consuming only while tracking a puck press
    iget v2, p0, Lcom/validator/cheto/PuckTapListener;->pendingPuckId:I

    if-eqz v2, :pass

    const/4 v4, 0x1

    return v4

    :pass
    const/4 v4, 0x0

    return v4
.end method
