.class public final Lcom/validator/cheto/SegmentedRainbowDrawable;
.super Landroid/graphics/drawable/Drawable;
.source "SegmentedRainbowDrawable.java"

.implements Ljava/lang/Runnable;

# Self-animating selected-button background used by the ShootIt puck popup.
# Kept in classes8 because Jawaker's primary DEX is already at its method-ref ceiling.
#
# The centre is one dark rounded rectangle. Its perimeter is split by
# PathMeasure into 16 equal-length, solid-colour segments. The fixed pattern is:
#   red, orange, yellow, green, blue, purple,
#   red, orange, yellow, green, blue, purple,
#   red, orange, yellow, green
# and advances by one whole segment every 60 ms. This is deliberately not a
# SweepGradient: adjacent segments remain hard colour blocks.

.field private static final FRAME_MS:J = 0x3cL

.field private static final SEGMENT_COUNT:I = 0x10

.field private mAlpha:I

.field private final mCenterColor:I

.field private final mCornerRadius:F

.field private final mFillPaint:Landroid/graphics/Paint;

.field private mLastCallback:Landroid/graphics/drawable/Drawable$Callback;

.field private final mMeasure:Landroid/graphics/PathMeasure;

.field private final mPath:Landroid/graphics/Path;

.field private final mRect:Landroid/graphics/RectF;

.field private mRunning:Z

.field private final mSegmentPath:Landroid/graphics/Path;

.field private final mStrokePaint:Landroid/graphics/Paint;

.field private final mStrokeWidth:F


# centerColor, borderPx, cornerRadius
.method public constructor <init>(IIF)V
    .locals 4

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    iput p1, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mCenterColor:I

    if-gtz p2, :border_ok

    const/4 p2, 0x1

    :border_ok
    int-to-float v0, p2

    iput v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mStrokeWidth:F

    const/4 v0, 0x0

    cmpl-float v1, p3, v0

    if-gtz v1, :radius_ok

    const/high16 p3, 0x3f800000    # 1.0f

    :radius_ok
    iput p3, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mCornerRadius:F

    const/16 v0, 0xff

    iput v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mAlpha:I

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1               # Paint.ANTI_ALIAS_FLAG

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mFillPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mStrokePaint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget v1, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mStrokeWidth:F

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    sget-object v1, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    sget-object v1, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mPath:Landroid/graphics/Path;

    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mSegmentPath:Landroid/graphics/Path;

    new-instance v0, Landroid/graphics/PathMeasure;

    invoke-direct {v0}, Landroid/graphics/PathMeasure;-><init>()V

    iput-object v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mMeasure:Landroid/graphics/PathMeasure;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mRect:Landroid/graphics/RectF;

    return-void
.end method


# The exact semi-opaque pool palette used by PredictionOverlay.colorFor().
.method private static colorForPatternIndex(I)I
    .locals 1

    if-nez p0, :orange

    const v0, -0x402b0000         # 0xBFD50000 red

    return v0

    :orange
    const/4 v0, 0x1

    if-ne p0, v0, :yellow

    const v0, -0x40009300         # 0xBFFF6D00 orange

    return v0

    :yellow
    const/4 v0, 0x2

    if-ne p0, v0, :green

    const v0, -0x40003d00         # 0xBFFFC300 yellow

    return v0

    :green
    const/4 v0, 0x3

    if-ne p0, v0, :blue

    const v0, -0x40d182ce         # 0xBF2E7D32 green

    return v0

    :blue
    const/4 v0, 0x4

    if-ne p0, v0, :purple

    const v0, -0x40ea9a40         # 0xBF1565C0 blue

    return v0

    :purple
    const v0, -0x4084e05e         # 0xBF7B1FA2 purple

    return v0
.end method


# Apply the Drawable's overall alpha without discarding each source colour's
# own alpha (the pool rainbow itself is intentionally 0xBF opaque).
.method private static modulateAlpha(II)I
    .locals 2

    ushr-int/lit8 v0, p0, 0x18

    mul-int/2addr v0, p1

    add-int/lit8 v0, v0, 0x7f

    const/16 v1, 0xff

    div-int/2addr v0, v1

    shl-int/lit8 v0, v0, 0x18

    const v1, 0xffffff

    and-int/2addr p0, v1

    or-int/2addr v0, p0

    return v0
.end method


# Schedule only after Android has attached this Drawable to a View. Remembering
# the callback also lets a detached/re-attached instance recover even if an old
# scheduled callback was discarded before run() had a chance to clear mRunning.
.method private ensureRunning()V
    .locals 4

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v0

    iget-object v1, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mLastCallback:Landroid/graphics/drawable/Drawable$Callback;

    if-eq v0, v1, :callback_unchanged

    iput-object v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mLastCallback:Landroid/graphics/drawable/Drawable$Callback;

    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mRunning:Z

    :callback_unchanged
    if-nez v0, :has_callback

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mRunning:Z

    return-void

    :has_callback
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    if-eqz v0, :not_visible

    iget-boolean v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mRunning:Z

    if-nez v0, :done

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mRunning:Z

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    const-wide/16 v2, 0x3c

    add-long/2addr v0, v2

    invoke-virtual {p0, p0, v0, v1}, Landroid/graphics/drawable/Drawable;->scheduleSelf(Ljava/lang/Runnable;J)V

    return-void

    :not_visible
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mRunning:Z

    :done
    return-void
.end method


.method public draw(Landroid/graphics/Canvas;)V
    .locals 14

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    iget v1, v0, Landroid/graphics/Rect;->left:I

    iget v2, v0, Landroid/graphics/Rect;->top:I

    iget v3, v0, Landroid/graphics/Rect;->right:I

    iget v4, v0, Landroid/graphics/Rect;->bottom:I

    if-le v3, v1, :finish

    if-le v4, v2, :finish

    int-to-float v1, v1

    int-to-float v2, v2

    int-to-float v3, v3

    int-to-float v4, v4

    iget-object v5, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mRect:Landroid/graphics/RectF;

    invoke-virtual {v5, v1, v2, v3, v4}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v6, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mFillPaint:Landroid/graphics/Paint;

    iget v3, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mCenterColor:I

    iget v4, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mAlpha:I

    invoke-static {v3, v4}, Lcom/validator/cheto/SegmentedRainbowDrawable;->modulateAlpha(II)I

    move-result v3

    invoke-virtual {v6, v3}, Landroid/graphics/Paint;->setColor(I)V

    iget v7, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mCornerRadius:F

    invoke-virtual {p1, v5, v7, v7, v6}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    # Keep the whole stroke inside the Drawable bounds.
    iget v6, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mStrokeWidth:F

    const/high16 v0, 0x40000000    # 2.0f

    div-float/2addr v6, v0

    invoke-virtual {v5, v6, v6}, Landroid/graphics/RectF;->inset(FF)V

    iget v7, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mCornerRadius:F

    sub-float/2addr v7, v6

    const/4 v0, 0x0

    cmpg-float v3, v7, v0

    if-gez v3, :radius_non_negative

    const/4 v7, 0x0

    :radius_non_negative
    iget-object v8, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mPath:Landroid/graphics/Path;

    invoke-virtual {v8}, Landroid/graphics/Path;->reset()V

    sget-object v0, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    invoke-virtual {v8, v5, v7, v7, v0}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    iget-object v9, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mMeasure:Landroid/graphics/PathMeasure;

    const/4 v0, 0x1

    invoke-virtual {v9, v8, v0}, Landroid/graphics/PathMeasure;->setPath(Landroid/graphics/Path;Z)V

    invoke-virtual {v9}, Landroid/graphics/PathMeasure;->getLength()F

    move-result v10

    const/4 v0, 0x0

    cmpl-float v0, v10, v0

    if-lez v0, :finish

    # A true rigid 16-step rotation. Modulo 16 happens before the six-colour
    # lookup, so the full fixed 16-entry pattern takes 16 * 60 ms to return.
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    const-wide/16 v2, 0x3c

    div-long/2addr v0, v2

    long-to-int v11, v0

    rem-int/lit8 v11, v11, 0x10

    const/4 v12, 0x0

    :segment_loop
    const/16 v0, 0x10

    if-ge v12, v0, :finish

    const/high16 v0, 0x41800000    # 16.0f

    int-to-float v1, v12

    mul-float/2addr v1, v10

    div-float/2addr v1, v0

    add-int/lit8 v2, v12, 0x1

    int-to-float v2, v2

    mul-float/2addr v2, v10

    div-float/2addr v2, v0

    iget-object v4, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mSegmentPath:Landroid/graphics/Path;

    invoke-virtual {v4}, Landroid/graphics/Path;->reset()V

    const/4 v0, 0x1

    invoke-virtual {v9, v1, v2, v4, v0}, Landroid/graphics/PathMeasure;->getSegment(FFLandroid/graphics/Path;Z)Z

    # Work around the old hardware-accelerated Path#getSegment zero-length
    # invalidation quirk without changing this segment's geometry.
    const/4 v0, 0x0

    invoke-virtual {v4, v0, v0}, Landroid/graphics/Path;->rLineTo(FF)V

    add-int v3, v12, v11

    rem-int/lit8 v3, v3, 0x10

    rem-int/lit8 v3, v3, 0x6

    invoke-static {v3}, Lcom/validator/cheto/SegmentedRainbowDrawable;->colorForPatternIndex(I)I

    move-result v3

    iget v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mAlpha:I

    invoke-static {v3, v0}, Lcom/validator/cheto/SegmentedRainbowDrawable;->modulateAlpha(II)I

    move-result v3

    iget-object v6, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mStrokePaint:Landroid/graphics/Paint;

    invoke-virtual {v6, v3}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p1, v4, v6}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    add-int/lit8 v12, v12, 0x1

    goto :segment_loop

    :finish
    invoke-direct {p0}, Lcom/validator/cheto/SegmentedRainbowDrawable;->ensureRunning()V

    return-void
.end method


.method public getOpacity()I
    .locals 1

    const/4 v0, -0x3             # PixelFormat.TRANSLUCENT

    return v0
.end method


.method public run()V
    .locals 1

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mRunning:Z

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    invoke-direct {p0}, Lcom/validator/cheto/SegmentedRainbowDrawable;->ensureRunning()V

    return-void
.end method


.method public setAlpha(I)V
    .locals 1

    if-gez p1, :alpha_non_negative

    const/4 p1, 0x0

    :alpha_non_negative
    const/16 v0, 0xff

    if-le p1, v0, :alpha_in_range

    move p1, v0

    :alpha_in_range
    iput p1, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mAlpha:I

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void
.end method


.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 1

    iget-object v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mFillPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    iget-object v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mStrokePaint:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void
.end method


.method public setVisible(ZZ)Z
    .locals 1

    invoke-super {p0, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    move-result v0

    if-eqz p1, :became_hidden

    invoke-virtual {p0}, Lcom/validator/cheto/SegmentedRainbowDrawable;->start()V

    goto :visibility_done

    :became_hidden
    invoke-virtual {p0}, Lcom/validator/cheto/SegmentedRainbowDrawable;->stop()V

    :visibility_done
    return v0
.end method


.method public start()V
    .locals 0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    invoke-direct {p0}, Lcom/validator/cheto/SegmentedRainbowDrawable;->ensureRunning()V

    return-void
.end method


.method public stop()V
    .locals 1

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/validator/cheto/SegmentedRainbowDrawable;->mRunning:Z

    invoke-virtual {p0, p0}, Landroid/graphics/drawable/Drawable;->unscheduleSelf(Ljava/lang/Runnable;)V

    return-void
.end method
