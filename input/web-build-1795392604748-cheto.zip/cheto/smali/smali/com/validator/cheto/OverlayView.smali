.class public Lcom/validator/cheto/OverlayView;
.super Landroid/view/View;
.source "OverlayView.java"

.implements Landroid/view/View$OnClickListener;

.implements Landroid/view/View$OnTouchListener;

.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;

# Hold-to-drag state for sliders (avoids accidental drags while scrolling).
.field private downAt:J

.field private dragArmed:Z

# Draggable-panel state: dragTarget is the view this listener moves (the panel);
# dragDX/dragDY hold the finger->view offset captured on ACTION_DOWN.
.field private dragTarget:Landroid/view/View;

.field private dragDX:F

.field private dragDY:F

# Horizontal-scroll snap-back: when set, this listener belongs to the console's
# HorizontalScrollView; on touch release it smooth-scrolls back to the left edge.
.field private hScrollSnap:Landroid/view/View;

.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V
    return-void
.end method

# Set by native (buildAutoAimMenu): the view this drag handle moves. Null => not a
# drag handle, so onTouch falls through to the slider/console logic.
.method public setDragTarget(Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Lcom/validator/cheto/OverlayView;->dragTarget:Landroid/view/View;

    return-void
.end method

# Set by native (buildMenu): marks this listener as the console HorizontalScrollView's
# snap-back handle. Non-null => onTouch snaps it back to the left edge on release.
.method public setHScrollSnap(Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Lcom/validator/cheto/OverlayView;->hScrollSnap:Landroid/view/View;

    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getId()I
    move-result v0

    invoke-virtual {p0, v0}, Lcom/validator/cheto/OverlayView;->onButtonClick(I)V
    return-void
.end method

# Touch handling. For a SeekBar (the transparency / preview-power sliders) this is
# a "hold-to-drag" gate: on touch-down we let the parent ScrollView keep control,
# and only after the finger is held still for ~160ms do we arm the drag and steal
# interception. Moves before that are swallowed so a tap/scroll over the slider is
# treated as a scroll/click instead of accidentally dragging it. For any other view
# (the console ScrollView) it keeps the original behaviour: let the inner view win
# its own vertical drag.
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 6

    # Hide button (hold-to-hide, view id 7412): route press/release into the existing native onButtonClick
    # (7412 on ACTION_DOWN, 7413 on ACTION_UP/CANCEL). Consume the gesture so ACTION_UP is guaranteed even if
    # the finger slides off — otherwise the top-right buttons could stay hidden. Mirror of OverlayView.kt.
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const v1, 0x1cf4

    if-ne v0, v1, :not_hide_btn

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    if-nez v0, :hide_not_down

    const v1, 0x1cf4

    invoke-virtual {p0, v1}, Lcom/validator/cheto/OverlayView;->onButtonClick(I)V

    const/4 v0, 0x1

    return v0

    :hide_not_down
    const/4 v1, 0x1

    if-eq v0, v1, :hide_release

    const/4 v1, 0x3

    if-eq v0, v1, :hide_release

    const/4 v0, 0x1

    return v0

    :hide_release
    const v1, 0x1cf5

    invoke-virtual {p0, v1}, Lcom/validator/cheto/OverlayView;->onButtonClick(I)V

    const/4 v0, 0x1

    return v0

    :not_hide_btn
    # Console horizontal-scroll snap-back: when this listener is the HSV's handle, let
    # the HorizontalScrollView scroll freely during DOWN/MOVE, and on UP/CANCEL smooth-
    # scroll it back to the left edge (consume so no fling fights the snap).
    iget-object v0, p0, Lcom/validator/cheto/OverlayView;->hScrollSnap:Landroid/view/View;

    if-eqz v0, :no_hsnap

    # Stop the menu/content ScrollViews ABOVE us from stealing this console gesture, so the
    # console's own vertical ScrollView (our direct parent) can scroll to its end and this
    # HorizontalScrollView can scroll sideways. We disallow intercept on the GRANDPARENT
    # (content) and up — NOT on our parent (the console ScrollView), which must stay free to
    # intercept vertical drags. p1.getParent() = console ScrollView; its parent = content.
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    move-result-object v3

    if-eqz v3, :hsnap_action

    invoke-interface {v3}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;
    move-result-object v3

    if-eqz v3, :hsnap_action

    const/4 v4, 0x1

    invoke-interface {v3, v4}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :hsnap_action
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I
    move-result v1

    const/4 v2, 0x1

    if-eq v1, v2, :hsnap_release

    const/4 v2, 0x3

    if-eq v1, v2, :hsnap_release

    # DOWN / MOVE: don't consume, the HorizontalScrollView scrolls with the finger.
    const/4 v0, 0x0

    return v0

    :hsnap_release
    # ACTION_UP / ACTION_CANCEL: smooth-scroll the HSV back to x=0.
    check-cast p1, Landroid/widget/HorizontalScrollView;

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1, v1, v2}, Landroid/widget/HorizontalScrollView;->smoothScrollTo(II)V

    const/4 v0, 0x1

    return v0

    :no_hsnap
    # Draggable panel: when a drag target is set, this listener is a title-bar drag
    # handle — move that view with the finger. Otherwise fall through to the slider/
    # console handling below.
    iget-object v0, p0, Lcom/validator/cheto/OverlayView;->dragTarget:Landroid/view/View;

    if-eqz v0, :no_drag

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I
    move-result v1

    if-nez v1, :drag_move

    # ACTION_DOWN: remember (target position - finger position).
    invoke-virtual {v0}, Landroid/view/View;->getX()F
    move-result v2

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F
    move-result v3

    sub-float/2addr v2, v3

    iput v2, p0, Lcom/validator/cheto/OverlayView;->dragDX:F

    invoke-virtual {v0}, Landroid/view/View;->getY()F
    move-result v2

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F
    move-result v3

    sub-float/2addr v2, v3

    iput v2, p0, Lcom/validator/cheto/OverlayView;->dragDY:F

    const/4 v0, 0x1

    return v0

    :drag_move
    const/4 v2, 0x2

    if-ne v1, v2, :drag_consume

    # ACTION_MOVE: target.setX(rawX + dX); target.setY(rawY + dY)
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F
    move-result v2

    iget v3, p0, Lcom/validator/cheto/OverlayView;->dragDX:F

    add-float/2addr v2, v3

    invoke-virtual {v0, v2}, Landroid/view/View;->setX(F)V

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F
    move-result v2

    iget v3, p0, Lcom/validator/cheto/OverlayView;->dragDY:F

    add-float/2addr v2, v3

    invoke-virtual {v0, v2}, Landroid/view/View;->setY(F)V

    :drag_consume
    const/4 v0, 0x1

    return v0

    :no_drag
    instance-of v0, p1, Landroid/widget/SeekBar;

    if-eqz v0, :console

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I
    move-result v0

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    move-result-object v1

    # ACTION_DOWN (0): record time, disarm, let the scroll view decide for now.
    if-nez v0, :not_down

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J
    move-result-wide v2

    iput-wide v2, p0, Lcom/validator/cheto/OverlayView;->downAt:J

    const/4 v2, 0x0

    iput-boolean v2, p0, Lcom/validator/cheto/OverlayView;->dragArmed:Z

    if-eqz v1, :ret_false

    const/4 v2, 0x0

    invoke-interface {v1, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    goto :ret_false

    :not_down
    # ACTION_MOVE (2)
    const/4 v2, 0x2

    if-ne v0, v2, :not_move

    iget-boolean v2, p0, Lcom/validator/cheto/OverlayView;->dragArmed:Z

    if-nez v2, :ret_false

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J
    move-result-wide v2

    iget-wide v4, p0, Lcom/validator/cheto/OverlayView;->downAt:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0xa0

    cmp-long v0, v2, v4

    if-ltz v0, :ret_true

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/validator/cheto/OverlayView;->dragArmed:Z

    if-eqz v1, :ret_false

    const/4 v0, 0x1

    invoke-interface {v1, v0}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    goto :ret_false

    :not_move
    # ACTION_UP (1) or ACTION_CANCEL (3)
    const/4 v2, 0x1

    if-eq v0, v2, :up

    const/4 v2, 0x3

    if-ne v0, v2, :ret_false

    :up
    iget-boolean v3, p0, Lcom/validator/cheto/OverlayView;->dragArmed:Z

    const/4 v2, 0x0

    iput-boolean v2, p0, Lcom/validator/cheto/OverlayView;->dragArmed:Z

    if-eqz v1, :up_decide

    const/4 v2, 0x0

    invoke-interface {v1, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :up_decide
    # if it never armed, consume the gesture so a tap doesn't jump the slider
    if-eqz v3, :ret_true

    :ret_false
    const/4 v0, 0x0

    return v0

    :ret_true
    const/4 v0, 0x1

    return v0

    :console
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    move-result-object v0

    if-eqz v0, :ret_false

    const/4 v1, 0x1

    invoke-interface {v0, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    goto :ret_false
.end method

.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 2

    if-eqz p3, :done

    # Route by view id: the preview-power slider (id 0xb = 11) goes to its own
    # native callback; everything else is the transparency slider.
    invoke-virtual {p1}, Landroid/view/View;->getId()I
    move-result v0

    const/16 v1, 0xb

    if-ne v0, v1, :transparency

    invoke-virtual {p0, p2}, Lcom/validator/cheto/OverlayView;->nativeOnPreviewSeekBarChanged(I)V

    goto :done

    :transparency
    invoke-virtual {p0, p2}, Lcom/validator/cheto/OverlayView;->nativeOnSeekBarChanged(I)V

    :done
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0

    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0

    return-void
.end method

.method public native onButtonClick(I)V
.end method

.method public native nativeOnSeekBarChanged(I)V
.end method

.method public native nativeOnPreviewSeekBarChanged(I)V
.end method
