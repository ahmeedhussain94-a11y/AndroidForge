.class public Lcom/validator/cheto/PredictionOverlay;
.super Landroid/view/View;
.source "PredictionOverlay.java"

# Marker-delimited overlay. Native (libcheto.so) pushes groups via
# updateMultiPoints([F)V:
#   [ -9999, ballNumber, radius, cx, cy, pocketColourKey,
#     x0,y0,x1,y1, x1,y1,x2,y2, ... ]
# Per group: line colour is always the real ball number (8-ball palette),
# drawLines(segments), and a circle at (cx,cy,radius) -- FILLED for solids
# (cue/1-8), STROKED for stripes (9-15). A header-only group (no segments) draws
# just the circle (cue marker).
# Marker is detected by value < -8192 to avoid an exact float compare.
# Potted balls: native flags them with a NEGATIVE radius -> draw the normal
# ball-coloured endpoint plus an outer target ring at the pocket. Owner is encoded
# via pocketColourKey: 100 = mine (green), 101 = opponent (red); cue/8/open pots
# keep the palette.
# Style marker 3 draws translucent red line-fill segments (ShootIt corner zones).
# Pure Android APIs only (no Kotlin runtime deps). Float array reads use 'aget'.


# instance fields
.field private pts:[F

.field private paint:Landroid/graphics/Paint;

.field private static lineAlphaPct:I = 0x4b


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x0

    new-array v0, v0, [F

    iput-object v0, p0, Lcom/validator/cheto/PredictionOverlay;->pts:[F

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v1, 0x40a00000

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iput-object v0, p0, Lcom/validator/cheto/PredictionOverlay;->paint:Landroid/graphics/Paint;

    return-void
.end method

# Returns an opaque ARGB colour for a ball number (8-ball palette; solid N and
# stripe N+8 share a colour).
.method private static colorFor(I)I
    .locals 2

    if-nez p0, :not_cue

    const v0, -0x40000001       # 0xBFFFFFFF white (cue / 0)

    return v0

    :not_cue
    const/16 v0, 0x8

    if-ne p0, v0, :not_eight

    const v0, -0x41000000       # 0xBF000000 black (8-ball)

    return v0

    :not_eight
    const/16 v0, 0x64

    if-ne p0, v0, :not_mine

    const v0, -0xff198a         # 0xFF00E676 green -- MY potted ball (key 100)

    return v0

    :not_mine
    const/16 v0, 0x65

    if-ne p0, v0, :not_opp

    const v0, -0xe8bc           # 0xFFFF1744 red -- opponent's potted ball (key 101)

    return v0

    :not_opp
    rem-int/lit8 v0, p0, 0x8

    const/4 v1, 0x1

    if-ne v0, v1, :g2

    const v0, -0x40003d00       # 0xBFFFC300 yellow

    return v0

    :g2
    const/4 v1, 0x2

    if-ne v0, v1, :g3

    const v0, -0x40ea9a40       # 0xBF1565C0 blue

    return v0

    :g3
    const/4 v1, 0x3

    if-ne v0, v1, :g4

    const v0, -0x402b0000       # 0xBFD50000 red

    return v0

    :g4
    const/4 v1, 0x4

    if-ne v0, v1, :g5

    const v0, -0x4084e05e       # 0xBF7B1FA2 purple

    return v0

    :g5
    const/4 v1, 0x5

    if-ne v0, v1, :g6

    const v0, -0x40009300       # 0xBFFF6D00 orange

    return v0

    :g6
    const/4 v1, 0x6

    if-ne v0, v1, :g7

    const v0, -0x40d182ce       # 0xBF2E7D32 green

    return v0

    :g7
    const v0, -0x4077f1b1       # 0xBF880E4F maroon (7, 15)

    return v0
.end method


# virtual methods
.method public updateMultiPoints([F)V
    .locals 0

    iput-object p1, p0, Lcom/validator/cheto/PredictionOverlay;->pts:[F

    invoke-virtual {p0}, Landroid/view/View;->postInvalidate()V

    return-void
.end method

.method public setLineAlphaPercent(I)V
    .locals 1

    const/4 v0, 0x5

    if-ge p1, v0, :alpha_min_ok

    const/4 p1, 0x5

    :alpha_min_ok
    const/16 v0, 0x64

    if-le p1, v0, :alpha_max_ok

    const/16 p1, 0x64

    :alpha_max_ok
    sput p1, Lcom/validator/cheto/PredictionOverlay;->lineAlphaPct:I

    invoke-virtual {p0}, Landroid/view/View;->postInvalidate()V

    return-void
.end method

.method public onDraw(Landroid/graphics/Canvas;)V
    # Keep p1 <= v15 for non-range Canvas invoke-* instructions.
    .locals 14

    iget-object v0, p0, Lcom/validator/cheto/PredictionOverlay;->pts:[F

    array-length v1, v0

    iget-object v4, p0, Lcom/validator/cheto/PredictionOverlay;->paint:Landroid/graphics/Paint;

    const v3, -0x3a000000                # 0xC6000000 = -8192.0f (marker threshold)

    const/4 v2, 0x0                      # v2 = i

    :outer
    add-int/lit8 v12, v2, 0x5

    if-ge v12, v1, :done                 # need 6 header floats

    aget v12, v0, v2

    cmpg-float v12, v12, v3

    if-gez v12, :advance                 # p[i] >= -8192 -> not a marker

    add-int/lit8 v12, v2, 0x1

    aget v5, v0, v12

    float-to-int v5, v5                  # v5 = ball number

    add-int/lit8 v12, v2, 0x2

    aget v6, v0, v12                     # v6 = radius

    add-int/lit8 v12, v2, 0x3

    aget v7, v0, v12                     # v7 = cx

    add-int/lit8 v12, v2, 0x4

    aget v8, v0, v12                     # v8 = cy

    add-int/lit8 v12, v2, 0x5

    aget v13, v0, v12

    float-to-int v13, v13                # v13 = pocket marker colour key

    add-int/lit8 v9, v2, 0x6             # v9 = segStart

    move v10, v9                         # v10 = j

    :scan
    if-ge v10, v1, :scan_done

    aget v12, v0, v10

    cmpg-float v12, v12, v3

    if-ltz v12, :scan_done               # p[j] < -8192 -> next marker

    add-int/lit8 v10, v10, 0x1

    goto :scan

    :scan_done
    sub-int v11, v10, v9                 # v11 = count

    # markerKey 3 = translucent red line-fill segments. It deliberately reuses
    # drawLines only, because this dex is already too close to its reference limits
    # for adding a new Canvas.drawRect / RectF reference.
    const/4 v12, 0x3

    if-ne v13, v12, :not_rect_marker

    const v12, -0xe8bc                   # 0xFFFF1744 red

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setColor(I)V

    const/16 v12, 0x55                   # translucent fill

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setAlpha(I)V

    sget-object v12, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v12, 0x4

    if-lt v11, v12, :no_circle

    invoke-virtual {p1, v0, v9, v11, v4}, Landroid/graphics/Canvas;->drawLines([FIILandroid/graphics/Paint;)V

    goto :no_circle

    :not_rect_marker
    invoke-static {v5}, Lcom/validator/cheto/PredictionOverlay;->colorFor(I)I

    move-result v12

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setColor(I)V

    sget v12, Lcom/validator/cheto/PredictionOverlay;->lineAlphaPct:I

    mul-int/lit16 v12, v12, 0xff

    div-int/lit8 v12, v12, 0x64

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setAlpha(I)V

    sget-object v12, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v12, 0x4

    if-lt v11, v12, :no_lines

    invoke-virtual {p1, v0, v9, v11, v4}, Landroid/graphics/Canvas;->drawLines([FIILandroid/graphics/Paint;)V

    :no_lines
    # Radius sign flags a potted ball: negative -> draw the normal solid/stripe
    # endpoint, then draw only the extra target ring in the ownership colour.
    const/4 v14, 0x0                     # v14 = potted flag

    const/4 v12, 0x0

    cmpg-float v12, v6, v12

    if-gez v12, :radius_ready

    neg-float v6, v6                     # magnitude of the negative radius

    const/4 v14, 0x1

    :radius_ready
    const/4 v12, 0x0

    cmpg-float v12, v6, v12

    if-lez v12, :no_circle               # radius <= 0 -> nothing to draw

    invoke-static {v5}, Lcom/validator/cheto/PredictionOverlay;->colorFor(I)I

    move-result v12

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setColor(I)V

    # When NOT potted (v14==0), pocketColourKey (v13) is a style code:
    #   2 = translucent solid fill (ball-radius rings)
    #   1 = solid fill (cue / shootit white-ball endpoint)
    #   else = default (solids 1-8 filled; cue/stripes stroked)
    if-nez v14, :style_default

    const/4 v12, 0x2

    if-ne v13, v12, :style_check_one

    const/16 v12, 0x66                   # ~40% alpha -> see-through fill

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setAlpha(I)V

    sget-object v12, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    goto :do_circle

    :style_check_one
    const/4 v12, 0x1

    if-ne v13, v12, :style_default

    sget v12, Lcom/validator/cheto/PredictionOverlay;->lineAlphaPct:I

    mul-int/lit16 v12, v12, 0xff

    div-int/lit8 v12, v12, 0x64

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setAlpha(I)V

    sget-object v12, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    goto :do_circle

    :style_default
    sget v12, Lcom/validator/cheto/PredictionOverlay;->lineAlphaPct:I

    mul-int/lit16 v12, v12, 0xff

    div-int/lit8 v12, v12, 0x64

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setAlpha(I)V

    if-eqz v5, :default_stroke           # cue (0) -> outlined like a stripe

    const/16 v12, 0x9

    if-ge v5, v12, :default_stroke       # ball >= 9 -> stripe -> STROKE

    sget-object v12, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    goto :default_set_style

    :default_stroke
    sget-object v12, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    :default_set_style
    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    :do_circle
    invoke-virtual {p1, v7, v8, v6, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    if-eqz v14, :no_circle

    if-eqz v13, :potted_ball_colour

    invoke-static {v13}, Lcom/validator/cheto/PredictionOverlay;->colorFor(I)I

    move-result v12

    goto :potted_colour_done

    :potted_ball_colour
    invoke-static {v5}, Lcom/validator/cheto/PredictionOverlay;->colorFor(I)I

    move-result v12

    :potted_colour_done
    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setColor(I)V

    sget v12, Lcom/validator/cheto/PredictionOverlay;->lineAlphaPct:I

    mul-int/lit16 v12, v12, 0xff

    div-int/lit8 v12, v12, 0x64

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setAlpha(I)V

    sget-object v12, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const v12, 0x3ff33333                # 1.9f outer target-ring scale

    mul-float v12, v6, v12

    invoke-virtual {p1, v7, v8, v12, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    :no_circle
    move v2, v10                         # i = j

    goto :outer

    :advance
    add-int/lit8 v2, v2, 0x1

    goto :outer

    :done
    return-void
.end method
