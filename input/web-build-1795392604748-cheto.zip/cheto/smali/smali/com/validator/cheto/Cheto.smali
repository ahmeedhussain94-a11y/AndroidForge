.class public final Lcom/validator/cheto/Cheto;
.super Ljava/lang/Object;
.source "Cheto.java"

.method public constructor <init>()V
    .locals 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static showMenu(Landroid/app/Activity;)V
    .locals 0

    invoke-static {p0}, Lcom/validator/cheto/Cheto;->nativeShowMenu(Landroid/app/Activity;)V
    return-void
.end method

.method private static native nativeShowMenu(Landroid/app/Activity;)V
.end method
