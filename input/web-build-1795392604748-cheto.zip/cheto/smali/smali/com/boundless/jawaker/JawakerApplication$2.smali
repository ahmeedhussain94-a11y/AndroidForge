.class final Lcom/boundless/jawaker/JawakerApplication$2;
.super Ljava/lang/Object;
.source "JawakerApplication.java"

.implements Ljava/lang/Runnable;

.field private final activity:Landroid/app/Activity;

.method constructor <init>(Landroid/app/Activity;)V
    .locals 0

    iput-object p1, p0, Lcom/boundless/jawaker/JawakerApplication$2;->activity:Landroid/app/Activity;
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public run()V
    .locals 3

    :try_start_0
    iget-object v0, p0, Lcom/boundless/jawaker/JawakerApplication$2;->activity:Landroid/app/Activity;
    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z
    move-result v0
    if-eqz v0, :cond_0
    return-void

    :cond_0
    const-string v0, "cheto"
    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/boundless/jawaker/JawakerApplication$2;->activity:Landroid/app/Activity;
    invoke-static {v0}, Lcom/validator/cheto/Cheto;->showMenu(Landroid/app/Activity;)V
    :try_end_0
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    const-string v1, "cheto"
    const-string v2, "Overlay launch failed"
    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-void
.end method
