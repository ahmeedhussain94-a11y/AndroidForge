.class final Lcom/boundless/jawaker/JawakerApplication$1;
.super Ljava/lang/Object;
.source "JawakerApplication.java"

.implements Landroid/app/Application$ActivityLifecycleCallbacks;

.field final synthetic this$0:Lcom/boundless/jawaker/JawakerApplication;

.method constructor <init>(Lcom/boundless/jawaker/JawakerApplication;)V
    .locals 0

    iput-object p1, p0, Lcom/boundless/jawaker/JawakerApplication$1;->this$0:Lcom/boundless/jawaker/JawakerApplication;
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0
    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .locals 0
    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 1

    iget-object v0, p0, Lcom/boundless/jawaker/JawakerApplication$1;->this$0:Lcom/boundless/jawaker/JawakerApplication;
    invoke-static {v0, p1}, Lcom/boundless/jawaker/JawakerApplication;->access$000(Lcom/boundless/jawaker/JawakerApplication;Landroid/app/Activity;)V

    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 0
    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 0
    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0
    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .locals 0
    return-void
.end method
