.class public Lcom/boundless/jawaker/JawakerApplication;
.super Landroidx/multidex/MultiDexApplication;
.source "JawakerApplication.java"

.field private injected:Z

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/multidex/MultiDexApplication;-><init>()V
    return-void
.end method

.method public onCreate()V
    .locals 1

    invoke-super {p0}, Landroidx/multidex/MultiDexApplication;->onCreate()V

    new-instance v0, Lcom/boundless/jawaker/JawakerApplication$1;
    invoke-direct {v0, p0}, Lcom/boundless/jawaker/JawakerApplication$1;-><init>(Lcom/boundless/jawaker/JawakerApplication;)V
    invoke-virtual {p0, v0}, Lcom/boundless/jawaker/JawakerApplication;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    return-void
.end method

.method static access$000(Lcom/boundless/jawaker/JawakerApplication;Landroid/app/Activity;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/boundless/jawaker/JawakerApplication;->launchOverlay(Landroid/app/Activity;)V
    return-void
.end method

.method private launchOverlay(Landroid/app/Activity;)V
    .locals 4

    iget-boolean v0, p0, Lcom/boundless/jawaker/JawakerApplication;->injected:Z
    if-eqz v0, :cond_0
    return-void

    :cond_0
    const/4 v0, 0x1
    iput-boolean v0, p0, Lcom/boundless/jawaker/JawakerApplication;->injected:Z

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;
    move-result-object v0

    new-instance v1, Landroid/os/Handler;
    invoke-direct {v1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v0, Lcom/boundless/jawaker/JawakerApplication$2;
    invoke-direct {v0, p1}, Lcom/boundless/jawaker/JawakerApplication$2;-><init>(Landroid/app/Activity;)V

    const-wide/16 v2, 0x4b0
    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
