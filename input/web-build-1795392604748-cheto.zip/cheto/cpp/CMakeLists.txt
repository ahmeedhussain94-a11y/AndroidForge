cmake_minimum_required(VERSION 3.22.1)

project("cheto")

# Produces libcheto.so — a minimal Dobby + IL2CPP hooking library.
# libdobby.so is loaded at runtime via dlopen (it must ship next to libcheto.so),
# so it is intentionally NOT linked here.
add_library(cheto SHARED
        native-lib.cpp)

find_library(log-lib log)
find_library(dl-lib dl)
find_library(android-lib android)

target_link_libraries(cheto
        ${log-lib}
        ${dl-lib}
        ${android-lib})

# NOTE: the old build also produced libgcore.so and ran patch_integrity.py as a
# POST_BUILD step to stamp/encrypt the integrity + scattered-offset vaults. Both
# were removed with the protection system; the sources and the built .so were
# deleted. See backup\cpp-src\ for the originals if you ever need to restore them.
