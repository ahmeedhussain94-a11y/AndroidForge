package com.validator.cheto

import android.app.Activity

/**
 * Entry point into libcheto.so.
 *
 * Call [showMenu] with the host [Activity] to draw the "Jawaker CHETO" overlay
 * menu in the top-left corner. All of the menu's construction and styling lives
 * in native code (native-lib.cpp); this object only loads the library and
 * forwards the activity.
 */
object Cheto {
    init {
        System.loadLibrary("cheto")
    }

    /** Build and attach the overlay menu to [activity]. */
    fun showMenu(activity: Activity) = nativeShowMenu(activity)

    private external fun nativeShowMenu(activity: Activity)
}
