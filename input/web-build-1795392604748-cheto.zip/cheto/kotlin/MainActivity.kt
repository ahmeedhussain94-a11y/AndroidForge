package com.validator.cheto

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Preview harness — NOT the product.
 *
 * The deliverable of this project is libcheto.so; this activity merely loads it
 * and asks it to draw the menu, so the overlay can be seen on a device/emulator.
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cheto.showMenu(this)
    }
}
