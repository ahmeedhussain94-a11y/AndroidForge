package com.validator.cheto

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/**
 * Dumb draw surface for the prediction line + ball outlines. ALL geometry is built
 * in native code (libcheto.so); this view only parses and draws.
 *
 * Wire format: a flat FloatArray of marker-delimited groups —
 *   [ -9999, ballNumber, radius, centreX, centreY, pocketColourKey,
 *     x0,y0,x1,y1, x1,y1,x2,y2, ... ]
 * Per group: line colour is always the real ball number (8-ball palette; solid N
 * and stripe N+8 share a colour), draw the segments (Canvas.drawLines format), then a circle of
 * `radius` at the centre. When NOT potted, the 6th float is a STYLE code:
 *   2 = translucent solid fill (ball-radius discs, any ball);
 *   1 = solid fill (cue / shootit white-ball endpoint);
 *   else = default (solids 1-8 filled, cue/stripes stroked).
 * A header-only group (no segments) draws just the circle. Line/fill opacity follows
 * the alpha slider (setLineAlphaPercent); the translucent fill uses a fixed alpha.
 * Marker detection uses a threshold (-8192) to avoid an exact float compare.
 *
 * Potted balls: native flags them by pushing the radius NEGATIVE. Such a ball keeps
 * its normal ball-coloured endpoint, plus an outer target ring at the pocket, so
 * the balls this shot will sink stand out from ordinary endpoints. For a potted
 * ball whose owner is known, native sends pocketColourKey 100 (mine -> green) or 101
 * (opponent -> red); cue/8-ball and open-table pots keep
 * the normal palette.
 *
 * NOTE: the shipped class is the hand-written smali at
 *   com.boundless.jawaker/smali/com/validator/cheto/PredictionOverlay.smali
 * (the gradle dex is NOT merged into the game, and it must stay free of Kotlin
 * runtime deps). This .kt is the readable source-of-truth — keep it equivalent.
 */
class PredictionOverlay(context: Context) : View(context) {

    @Volatile
    private var pts: FloatArray = FloatArray(0)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    // Overlay line/fill opacity (percent, 5..100). Driven from native via setLineAlphaPercent.
    // Smali keeps this as a static field; with a single overlay instance it's equivalent.
    private var lineAlphaPct = 0x4b   // 75%

    /** Called from native code (any thread — postInvalidate is thread-safe). */
    fun updateMultiPoints(points: FloatArray) {
        pts = points
        postInvalidate()
    }

    /** Called from native code: overlay line/fill opacity, clamped to 5..100 %. */
    fun setLineAlphaPercent(pct: Int) {
        var v = pct
        if (v < 5) v = 5
        if (v > 100) v = 100
        lineAlphaPct = v
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val p = pts
        val n = p.size
        val lineAlpha = lineAlphaPct * 255 / 100
        var i = 0
        while (i + 5 < n) {
            if (p[i] >= MARKER_THRESHOLD) { i++; continue }   // not a marker -> skip
            val ballNum = p[i + 1].toInt()
            val rawRadius = p[i + 2]
            val potted = rawRadius < 0f                        // native flags pots with a negative radius
            val radius = if (rawRadius < 0f) -rawRadius else rawRadius
            val cx = p[i + 3]
            val cy = p[i + 4]
            val pocketColourKey = p[i + 5].toInt()
            val segStart = i + 6
            var j = segStart
            while (j < n && p[j] >= MARKER_THRESHOLD) j++       // scan to the next marker
            val count = j - segStart

            // line: ball-coloured, honouring the alpha slider
            paint.color = colorFor(ballNum)
            paint.alpha = lineAlpha
            paint.style = Paint.Style.STROKE
            if (count >= 4) canvas.drawLines(p, segStart, count, paint)
            if (radius > 0f) {
                // When NOT potted, pocketColourKey is a style code (must match the shipped smali):
                //   2 = translucent solid fill (ball-radius discs, any ball)
                //   1 = solid fill (cue / shootit white-ball endpoint — old-lib solid ending)
                //   else = default (solids 1-8 filled; cue/stripes stroked)
                if (!potted && pocketColourKey == 2) {
                    paint.color = colorFor(ballNum)
                    paint.alpha = RADIUS_FILL_ALPHA            // fixed see-through alpha (independent of the slider)
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, radius, paint)
                } else if (!potted && pocketColourKey == 1) {
                    paint.color = colorFor(ballNum)
                    paint.alpha = lineAlpha
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, radius, paint)
                } else {
                    paint.color = colorFor(ballNum)
                    paint.alpha = lineAlpha
                    paint.style = if (ballNum in 1..8) Paint.Style.FILL else Paint.Style.STROKE
                    canvas.drawCircle(cx, cy, radius, paint)

                    if (potted) {
                        // Only the extra potted target ring uses ownership colour.
                        paint.color = colorFor(if (pocketColourKey != 0) pocketColourKey else ballNum)
                        paint.alpha = lineAlpha
                        paint.style = Paint.Style.STROKE
                        canvas.drawCircle(cx, cy, radius * POTTED_RING_SCALE, paint)
                    }
                }
            }

            i = j
        }
    }

    companion object {
        private const val MARKER_THRESHOLD = -8192f
        private const val POTTED_RING_SCALE = 1.9f    // outer target ring vs ball radius
        private const val RADIUS_FILL_ALPHA = 0x66    // ~40% alpha for the translucent ball-radius discs

        // Exact old-lib BALL_COLORS at 75% alpha (lineAlpha=191 -> 0xBF). Solid N
        // and stripe N+8 share a colour. Keyed by the REAL ball number.
        private fun colorFor(n: Int): Int = when {
            n == 0 -> -0x40000001     // 0xBFFFFFFF white (cue)
            n == 8 -> -0x41000000     // 0xBF000000 black (8-ball)
            n == 100 -> -0xff198a     // 0xFF00E676 bright green — MY potted ball
            n == 101 -> -0xe8bc       // 0xFFFF1744 bright red   — opponent's potted ball
            else -> when (n % 8) {
                1 -> -0x40003d00      // 0xBFFFC300 yellow
                2 -> -0x40ea9a40      // 0xBF1565C0 blue
                3 -> -0x402b0000      // 0xBFD50000 red
                4 -> -0x4084e05e      // 0xBF7B1FA2 purple
                5 -> -0x40009300      // 0xBFFF6D00 orange
                6 -> -0x40d182ce      // 0xBF2E7D32 green
                else -> -0x4077f1b1   // 0xBF880E4F maroon (7, 15)
            }
        }
    }
}
