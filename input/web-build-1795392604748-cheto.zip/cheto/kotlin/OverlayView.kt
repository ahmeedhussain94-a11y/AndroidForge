package com.validator.cheto

import android.content.Context
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.SeekBar

/**
 * Click / touch / slider dispatcher for the native overlay menu.
 *
 * A listener interface cannot be implemented from native code alone, so the
 * native library ([Cheto]) creates one of these per interactive view and routes
 * the event, by the view's id, into native code.
 *
 * NOTE: at runtime the build injects the hand-written smali at
 * com.boundless.jawaker/smali/com/validator/cheto/OverlayView.smali — that is the
 * source of truth. Keep this file in sync with it.
 */
class OverlayView(context: Context) : View(context),
    View.OnClickListener, View.OnTouchListener, SeekBar.OnSeekBarChangeListener {

    override fun onClick(v: View) {
        onButtonClick(v.id)
    }

    // Hold-to-drag state for the sliders (avoids accidental drags while scrolling).
    private var downAt = 0L
    private var dragArmed = false

    // Draggable-panel state: the view this listener moves (the panel) + finger offset.
    private var dragTarget: View? = null
    private var dragDX = 0f
    private var dragDY = 0f

    // Console horizontal-scroll snap-back: the HorizontalScrollView this listener
    // resets to the left edge on touch release (null => not the snap-back handle).
    private var hScrollSnap: View? = null

    /** Set by native (buildAutoAimMenu): makes this a title-bar drag handle for [target]. */
    fun setDragTarget(target: View) { dragTarget = target }

    /** Set by native (buildMenu): marks this as the console HSV's snap-back handle. */
    fun setHScrollSnap(target: View) { hScrollSnap = target }

    /**
     * For a SeekBar (transparency / preview-power sliders) this is a "hold-to-drag"
     * gate: on touch-down we let the parent ScrollView keep control, and only after
     * the finger is held still for ~160ms do we arm the drag and steal interception.
     * Moves before that are swallowed, so a tap/scroll over a slider scrolls the menu
     * instead of accidentally dragging it. Any other view (the console) keeps the
     * original behaviour: let the inner scrollable view win its own vertical drag.
     */
    override fun onTouch(v: View, event: MotionEvent): Boolean {
        // Hide button (hold-to-hide): route press/release into the existing native onButtonClick so no new
        // native method is needed. Consume the gesture (return true) so ACTION_UP/CANCEL is guaranteed to
        // arrive even if the finger slides off — otherwise the top-right buttons could stay hidden.
        if (v.id == HIDE_BTN_ID) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> onButtonClick(HIDE_PRESS_ID)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onButtonClick(HIDE_RELEASE_ID)
            }
            return true
        }
        // Console horizontal-scroll snap-back: free scrolling during DOWN/MOVE, then on
        // UP/CANCEL smooth-scroll back to the left edge (consume so no fling fights it).
        if (hScrollSnap != null) {
            // Stop the menu/content ScrollViews above us from stealing this console gesture so
            // the console's own vertical ScrollView (our parent) can reach its end and this HSV
            // can scroll sideways. Disallow intercept on the GRANDPARENT (content) and up, NOT
            // our parent (the console ScrollView), which stays free to intercept vertical drags.
            (v.parent?.parent)?.requestDisallowInterceptTouchEvent(true)
            when (event.actionMasked) {
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    (v as? HorizontalScrollView)?.smoothScrollTo(0, 0)
                    return true
                }
            }
            return false
        }
        // Draggable panel: when a drag target is set this is a title-bar drag handle —
        // move that view with the finger. Otherwise fall through to the slider/console logic.
        val target = dragTarget
        if (target != null) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragDX = target.x - event.rawX
                    dragDY = target.y - event.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    target.x = event.rawX + dragDX
                    target.y = event.rawY + dragDY
                }
            }
            return true
        }
        if (v !is SeekBar) {
            v.parent?.requestDisallowInterceptTouchEvent(true)
            return false
        }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downAt = SystemClock.uptimeMillis()
                dragArmed = false
                v.parent?.requestDisallowInterceptTouchEvent(false)
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragArmed) return false
                if (SystemClock.uptimeMillis() - downAt >= HOLD_MS) {
                    dragArmed = true
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    return false
                }
                return true // still in the hold window: swallow so the menu scrolls
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val wasArmed = dragArmed
                dragArmed = false
                v.parent?.requestDisallowInterceptTouchEvent(false)
                return !wasArmed // a tap that never armed is consumed (no slider jump)
            }
        }
        return false
    }

    /** Slider moved: route by view id (preview slider vs transparency slider). */
    override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
        if (!fromUser) return
        if (seekBar.id == PREVIEW_SEEK_VIEW_ID) nativeOnPreviewSeekBarChanged(progress)
        else nativeOnSeekBarChanged(progress)
    }

    override fun onStartTrackingTouch(seekBar: SeekBar) {}
    override fun onStopTrackingTouch(seekBar: SeekBar) {}

    /** Implemented in libcheto.so (registered via RegisterNatives). */
    external fun onButtonClick(id: Int)
    external fun nativeOnSeekBarChanged(progress: Int)
    external fun nativeOnPreviewSeekBarChanged(progress: Int)

    companion object {
        /** Must match PREVIEW_SEEK_VIEW_ID in native-lib.cpp and OverlayView.smali. */
        const val PREVIEW_SEEK_VIEW_ID = 11

        /** Hide button: view id + the press/release ids it routes into onButtonClick.
         *  Must match SI_POPUP_HIDE_PRESS_ID / SI_POPUP_HIDE_RELEASE_ID in native-lib.cpp and the smali. */
        const val HIDE_BTN_ID = 7412       // == HIDE_PRESS_ID (the button's own view id)
        const val HIDE_PRESS_ID = 7412
        const val HIDE_RELEASE_ID = 7413

        /** Hold this long before a slider drag arms (matches OverlayView.smali = 0xa0). */
        const val HOLD_MS = 160L
    }
}
