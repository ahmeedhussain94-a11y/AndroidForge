package com.example.practicehelper;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.content.Context;
import java.util.Locale;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 18, 18, 12);
        root.setBackgroundColor(Color.rgb(16, 35, 28));
        TextView title = new TextView(this);
        title.setText("BILLIARDS PRACTICE HELPER"); title.setTextColor(Color.WHITE);
        title.setTextSize(20); title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        TextView help = new TextView(this);
        help.setText("Drag the cue and object balls. Tap a pocket to set the target. The guide shows a practice aiming line and ghost-ball position.");
        help.setTextColor(Color.rgb(215,225,218)); help.setTextSize(13);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2); hp.topMargin=8; hp.bottomMargin=10; root.addView(help,hp);
        TableView table = new TableView(this);
        root.addView(table, new LinearLayout.LayoutParams(-1, 0, 1));
        Button reset = new Button(this); reset.setText("Reset positions");
        reset.setOnClickListener(v -> table.reset()); root.addView(reset);
        TextView foot = new TextView(this);
        foot.setText("Offline practice tool only · No Jawaker connection, game control, or automation");
        foot.setTextColor(Color.LTGRAY); foot.setTextSize(11); foot.setGravity(Gravity.CENTER);
        root.addView(foot);
        setContentView(root);
    }

    static class TableView extends View {
        Paint p = new Paint(3);
        float cueX=.28f, cueY=.60f, objX=.62f, objY=.42f;
        int pocket=1; float[][] pockets={{.08f,.13f},{.50f,.10f},{.92f,.13f},{.08f,.87f},{.50f,.90f},{.92f,.87f}};
        int selected=1; int dragging=0; float left,top,w,h,ballR;
        TableView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void reset(){cueX=.28f;cueY=.60f;objX=.62f;objY=.42f;selected=1;invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float pad=18; left=pad;top=pad;w=getWidth()-2*pad;h=getHeight()-2*pad;ballR=Math.min(w,h)*.035f;
            p.setColor(Color.rgb(102,63,35)); c.drawRoundRect(left-12,top-12,left+w+12,top+h+12,22,22,p);
            p.setColor(Color.rgb(20,111,69)); c.drawRoundRect(left,top,left+w,top+h,12,12,p);
            p.setColor(Color.rgb(8,20,15)); for(int i=0;i<6;i++){float[] q=pockets[i]; c.drawCircle(left+q[0]*w,top+q[1]*h,ballR*1.45f,p);}
            float px=left+pockets[selected][0]*w, py=top+pockets[selected][1]*h;
            p.setColor(Color.YELLOW);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawCircle(px,py,ballR*2.0f,p);p.setStyle(Paint.Style.FILL);
            // Object-to-pocket direction and ghost-ball location.
            float dx=px-(left+objX*w),dy=py-(top+objY*h);float len=(float)Math.hypot(dx,dy);if(len>1){dx/=len;dy/=len;}
            float gx=left+objX*w-dx*ballR*2, gy=top+objY*h-dy*ballR*2;
            p.setColor(Color.rgb(255,220,80));p.setStrokeWidth(3);p.setStyle(Paint.Style.STROKE);c.drawLine(left+cueX*w,top+cueY*h,gx,gy,p);c.drawLine(left+objX*w,top+objY*h,px,py,p);p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(85,255,255,255));c.drawCircle(gx,gy,ballR,p);p.setColor(Color.WHITE);c.drawCircle(left+cueX*w,top+cueY*h,ballR,p);
            p.setColor(Color.rgb(220,45,45));c.drawCircle(left+objX*w,top+objY*h,ballR,p);
            p.setColor(Color.BLACK);p.setTextSize(24);c.drawText("C",left+cueX*w-7,top+cueY*h+8,p);c.drawText("1",left+objX*w-6,top+objY*h+8,p);
            p.setColor(Color.WHITE);p.setTextSize(13);String info=String.format(Locale.US,"Target pocket %d · Ghost-ball guide",selected+1);c.drawText(info,left+8,top+h-12,p);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY(); if(e.getAction()==MotionEvent.ACTION_DOWN){float cx=left+cueX*w,cy=top+cueY*h,ox=left+objX*w,oy=top+objY*h; if(Math.hypot(x-cx,y-cy)<ballR*2.5)dragging=1;else if(Math.hypot(x-ox,y-oy)<ballR*2.5)dragging=2;else{double best=Double.MAX_VALUE;for(int i=0;i<6;i++){double d=Math.hypot(x-(left+pockets[i][0]*w),y-(top+pockets[i][1]*h));if(d<best){best=d;selected=i;}}if(best>ballR*4)dragging=0;invalidate();}return true;} if(e.getAction()==MotionEvent.ACTION_MOVE&&dragging!=0){float nx=Math.max(.05f,Math.min(.95f,(x-left)/w)),ny=Math.max(.08f,Math.min(.92f,(y-top)/h));if(dragging==1){cueX=nx;cueY=ny;}else{objX=nx;objY=ny;}invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_UP){dragging=0;performClick();return true;}return true;}
        @Override public boolean performClick(){super.performClick();return true;}
    }
}
