# Billiards Practice Helper (Android)

A small, offline Android Studio project created as a safe standalone practice aid. It is not a Jawaker loader and does not connect to, inject into, read from, or automate Jawaker or any other game.

## Features
- Drag the cue ball and object ball to set up a practice shot.
- Tap one of six pockets to select a target.
- Displays a simple object-ball path and ghost-ball aiming reference.
- Reset button.

## Build
1. Open this folder in Android Studio (Giraffe or newer recommended).
2. Allow Gradle sync; use JDK 17 and install Android SDK Platform 35.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio writes the debug APK under `app/build/outputs/apk/debug/`.

The project uses Android Gradle Plugin 8.6.1 and compileSdk 35. An internet connection may be required on first Gradle sync to download dependencies.
